package com.practica.compras.model;

public enum EstadoCompra {
    PENDIENTE,
    PAGADA,
    CANCELADA
}